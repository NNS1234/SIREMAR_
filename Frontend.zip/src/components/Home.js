/* 
Nudrat Nawal Saber 1001733394
Feng Jiang 1001888843
Singh Sankalp Sandeep  1001964065
*/
import React from 'react'
import Header from './Header'

const Home = () => {
  return (
    <div className='Home'>
        <Header/>
        <section>
        <p>This is Siremar</p>
        <h1>A portal for residents of Margarita</h1>
        <button className='Button'>Get Started</button>
        </section>
    </div>
  )
}

export default Home